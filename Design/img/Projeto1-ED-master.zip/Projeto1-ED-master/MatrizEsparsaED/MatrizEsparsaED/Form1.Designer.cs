﻿namespace MatrizEsparsaED
{
    partial class frm_matrizEsparsa
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_lerarq = new System.Windows.Forms.Button();
            this.dlg_abrir = new System.Windows.Forms.OpenFileDialog();
            this.tbx_valor = new System.Windows.Forms.TextBox();
            this.btn_criarMatriz = new System.Windows.Forms.Button();
            this.lb_valor2 = new System.Windows.Forms.Label();
            this.nmr_M = new System.Windows.Forms.NumericUpDown();
            this.nmr_N = new System.Windows.Forms.NumericUpDown();
            this.btn_addElemento = new System.Windows.Forms.Button();
            this.btn_lerElemento = new System.Windows.Forms.Button();
            this.btn_Exibir = new System.Windows.Forms.Button();
            this.btn_excluirMatriz = new System.Windows.Forms.Button();
            this.btn_excluirElemento = new System.Windows.Forms.Button();
            this.lb_N = new System.Windows.Forms.Label();
            this.lb_M = new System.Windows.Forms.Label();
            this.lb_coluna = new System.Windows.Forms.Label();
            this.lb_valor = new System.Windows.Forms.Label();
            this.nmr_coluna = new System.Windows.Forms.NumericUpDown();
            this.btn_addValor = new System.Windows.Forms.Button();
            this.btn_somarMatrizes = new System.Windows.Forms.Button();
            this.btn_multiplicarMatrizes = new System.Windows.Forms.Button();
            this.lb_sinalMat = new System.Windows.Forms.Label();
            this.lb_sinalResultado = new System.Windows.Forms.Label();
            this.tbx_valor2 = new System.Windows.Forms.TextBox();
            this.lsv_matriz = new System.Windows.Forms.DataGridView();
            this.lsv_1 = new System.Windows.Forms.DataGridView();
            this.lsv_2 = new System.Windows.Forms.DataGridView();
            this.lsv_resultado = new System.Windows.Forms.DataGridView();
            this.btn_lerArquivo1 = new System.Windows.Forms.Button();
            this.btn_lerArquivo2 = new System.Windows.Forms.Button();
            this.btn_mostrar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nmr_M)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmr_N)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmr_coluna)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lsv_matriz)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lsv_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lsv_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lsv_resultado)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_lerarq
            // 
            this.btn_lerarq.Location = new System.Drawing.Point(359, 151);
            this.btn_lerarq.Name = "btn_lerarq";
            this.btn_lerarq.Size = new System.Drawing.Size(75, 23);
            this.btn_lerarq.TabIndex = 0;
            this.btn_lerarq.Text = "Ler Arquivo";
            this.btn_lerarq.UseVisualStyleBackColor = true;
            this.btn_lerarq.Click += new System.EventHandler(this.btn_lerarq_Click);
            // 
            // tbx_valor
            // 
            this.tbx_valor.Location = new System.Drawing.Point(439, 99);
            this.tbx_valor.Name = "tbx_valor";
            this.tbx_valor.Size = new System.Drawing.Size(120, 20);
            this.tbx_valor.TabIndex = 1;
            // 
            // btn_criarMatriz
            // 
            this.btn_criarMatriz.Location = new System.Drawing.Point(307, 122);
            this.btn_criarMatriz.Name = "btn_criarMatriz";
            this.btn_criarMatriz.Size = new System.Drawing.Size(75, 23);
            this.btn_criarMatriz.TabIndex = 2;
            this.btn_criarMatriz.Text = "Criar Matriz";
            this.btn_criarMatriz.UseVisualStyleBackColor = true;
            this.btn_criarMatriz.Click += new System.EventHandler(this.btn_criarMatriz_Click);
            // 
            // lb_valor2
            // 
            this.lb_valor2.AutoSize = true;
            this.lb_valor2.Location = new System.Drawing.Point(400, 102);
            this.lb_valor2.Name = "lb_valor2";
            this.lb_valor2.Size = new System.Drawing.Size(34, 13);
            this.lb_valor2.TabIndex = 3;
            this.lb_valor2.Text = "Valor:";
            // 
            // nmr_M
            // 
            this.nmr_M.Location = new System.Drawing.Point(439, 47);
            this.nmr_M.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nmr_M.Name = "nmr_M";
            this.nmr_M.Size = new System.Drawing.Size(120, 20);
            this.nmr_M.TabIndex = 4;
            // 
            // nmr_N
            // 
            this.nmr_N.Location = new System.Drawing.Point(439, 73);
            this.nmr_N.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nmr_N.Name = "nmr_N";
            this.nmr_N.Size = new System.Drawing.Size(120, 20);
            this.nmr_N.TabIndex = 5;
            // 
            // btn_addElemento
            // 
            this.btn_addElemento.Location = new System.Drawing.Point(388, 122);
            this.btn_addElemento.Name = "btn_addElemento";
            this.btn_addElemento.Size = new System.Drawing.Size(96, 23);
            this.btn_addElemento.TabIndex = 6;
            this.btn_addElemento.Text = "Adicionar/Alterar";
            this.btn_addElemento.UseVisualStyleBackColor = true;
            this.btn_addElemento.Click += new System.EventHandler(this.btn_addElemento_Click);
            // 
            // btn_lerElemento
            // 
            this.btn_lerElemento.Location = new System.Drawing.Point(491, 122);
            this.btn_lerElemento.Name = "btn_lerElemento";
            this.btn_lerElemento.Size = new System.Drawing.Size(75, 23);
            this.btn_lerElemento.TabIndex = 7;
            this.btn_lerElemento.Text = "Pegar Valor";
            this.btn_lerElemento.UseVisualStyleBackColor = true;
            this.btn_lerElemento.Click += new System.EventHandler(this.btn_lerElemento_Click);
            // 
            // btn_Exibir
            // 
            this.btn_Exibir.Location = new System.Drawing.Point(1015, 272);
            this.btn_Exibir.Name = "btn_Exibir";
            this.btn_Exibir.Size = new System.Drawing.Size(75, 23);
            this.btn_Exibir.TabIndex = 9;
            this.btn_Exibir.Text = "Exibir Matriz";
            this.btn_Exibir.UseVisualStyleBackColor = true;
            this.btn_Exibir.Click += new System.EventHandler(this.btn_Exibir_Click);
            // 
            // btn_excluirMatriz
            // 
            this.btn_excluirMatriz.Location = new System.Drawing.Point(443, 151);
            this.btn_excluirMatriz.Name = "btn_excluirMatriz";
            this.btn_excluirMatriz.Size = new System.Drawing.Size(92, 23);
            this.btn_excluirMatriz.TabIndex = 10;
            this.btn_excluirMatriz.Text = "Excluir Matriz";
            this.btn_excluirMatriz.UseVisualStyleBackColor = true;
            this.btn_excluirMatriz.Click += new System.EventHandler(this.btn_excluirMatriz_Click);
            // 
            // btn_excluirElemento
            // 
            this.btn_excluirElemento.Location = new System.Drawing.Point(572, 122);
            this.btn_excluirElemento.Name = "btn_excluirElemento";
            this.btn_excluirElemento.Size = new System.Drawing.Size(95, 23);
            this.btn_excluirElemento.TabIndex = 11;
            this.btn_excluirElemento.Text = "Excluir Elemento";
            this.btn_excluirElemento.UseVisualStyleBackColor = true;
            this.btn_excluirElemento.Click += new System.EventHandler(this.btn_excluirElemento_Click);
            // 
            // lb_N
            // 
            this.lb_N.AutoSize = true;
            this.lb_N.Location = new System.Drawing.Point(397, 54);
            this.lb_N.Name = "lb_N";
            this.lb_N.Size = new System.Drawing.Size(36, 13);
            this.lb_N.TabIndex = 12;
            this.lb_N.Text = "Linha:";
            // 
            // lb_M
            // 
            this.lb_M.AutoSize = true;
            this.lb_M.Location = new System.Drawing.Point(385, 75);
            this.lb_M.Name = "lb_M";
            this.lb_M.Size = new System.Drawing.Size(43, 13);
            this.lb_M.TabIndex = 13;
            this.lb_M.Text = "Coluna:";
            // 
            // lb_coluna
            // 
            this.lb_coluna.AutoSize = true;
            this.lb_coluna.Location = new System.Drawing.Point(21, 23);
            this.lb_coluna.Name = "lb_coluna";
            this.lb_coluna.Size = new System.Drawing.Size(43, 13);
            this.lb_coluna.TabIndex = 17;
            this.lb_coluna.Text = "Coluna:";
            // 
            // lb_valor
            // 
            this.lb_valor.AutoSize = true;
            this.lb_valor.Location = new System.Drawing.Point(30, 49);
            this.lb_valor.Name = "lb_valor";
            this.lb_valor.Size = new System.Drawing.Size(34, 13);
            this.lb_valor.TabIndex = 16;
            this.lb_valor.Text = "Valor:";
            // 
            // nmr_coluna
            // 
            this.nmr_coluna.Location = new System.Drawing.Point(70, 21);
            this.nmr_coluna.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nmr_coluna.Name = "nmr_coluna";
            this.nmr_coluna.Size = new System.Drawing.Size(120, 20);
            this.nmr_coluna.TabIndex = 14;
            // 
            // btn_addValor
            // 
            this.btn_addValor.Location = new System.Drawing.Point(79, 73);
            this.btn_addValor.Name = "btn_addValor";
            this.btn_addValor.Size = new System.Drawing.Size(91, 23);
            this.btn_addValor.TabIndex = 18;
            this.btn_addValor.Text = "Adicionar Valor";
            this.btn_addValor.UseVisualStyleBackColor = true;
            this.btn_addValor.Click += new System.EventHandler(this.btn_addValor_Click);
            // 
            // btn_somarMatrizes
            // 
            this.btn_somarMatrizes.Location = new System.Drawing.Point(307, 529);
            this.btn_somarMatrizes.Name = "btn_somarMatrizes";
            this.btn_somarMatrizes.Size = new System.Drawing.Size(90, 23);
            this.btn_somarMatrizes.TabIndex = 22;
            this.btn_somarMatrizes.Text = "Somar Matrizes";
            this.btn_somarMatrizes.UseVisualStyleBackColor = true;
            this.btn_somarMatrizes.Click += new System.EventHandler(this.btn_somarMatrizes_Click);
            // 
            // btn_multiplicarMatrizes
            // 
            this.btn_multiplicarMatrizes.Location = new System.Drawing.Point(427, 529);
            this.btn_multiplicarMatrizes.Name = "btn_multiplicarMatrizes";
            this.btn_multiplicarMatrizes.Size = new System.Drawing.Size(108, 23);
            this.btn_multiplicarMatrizes.TabIndex = 23;
            this.btn_multiplicarMatrizes.Text = "Multiplicar Matrizes";
            this.btn_multiplicarMatrizes.UseVisualStyleBackColor = true;
            this.btn_multiplicarMatrizes.Click += new System.EventHandler(this.btn_multiplicarMatrizes_Click);
            // 
            // lb_sinalMat
            // 
            this.lb_sinalMat.AutoSize = true;
            this.lb_sinalMat.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_sinalMat.Location = new System.Drawing.Point(267, 359);
            this.lb_sinalMat.Name = "lb_sinalMat";
            this.lb_sinalMat.Size = new System.Drawing.Size(21, 24);
            this.lb_sinalMat.TabIndex = 24;
            this.lb_sinalMat.Text = "+";
            // 
            // lb_sinalResultado
            // 
            this.lb_sinalResultado.AutoSize = true;
            this.lb_sinalResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_sinalResultado.Location = new System.Drawing.Point(551, 359);
            this.lb_sinalResultado.Name = "lb_sinalResultado";
            this.lb_sinalResultado.Size = new System.Drawing.Size(21, 24);
            this.lb_sinalResultado.TabIndex = 25;
            this.lb_sinalResultado.Text = "=";
            // 
            // tbx_valor2
            // 
            this.tbx_valor2.Location = new System.Drawing.Point(70, 46);
            this.tbx_valor2.Name = "tbx_valor2";
            this.tbx_valor2.Size = new System.Drawing.Size(120, 20);
            this.tbx_valor2.TabIndex = 26;
            // 
            // lsv_matriz
            // 
            this.lsv_matriz.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.lsv_matriz.Location = new System.Drawing.Point(673, 11);
            this.lsv_matriz.Name = "lsv_matriz";
            this.lsv_matriz.Size = new System.Drawing.Size(417, 246);
            this.lsv_matriz.TabIndex = 27;
            // 
            // lsv_1
            // 
            this.lsv_1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.lsv_1.Location = new System.Drawing.Point(12, 272);
            this.lsv_1.Name = "lsv_1";
            this.lsv_1.Size = new System.Drawing.Size(251, 191);
            this.lsv_1.TabIndex = 28;
            // 
            // lsv_2
            // 
            this.lsv_2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.lsv_2.Location = new System.Drawing.Point(294, 272);
            this.lsv_2.Name = "lsv_2";
            this.lsv_2.Size = new System.Drawing.Size(251, 191);
            this.lsv_2.TabIndex = 29;
            // 
            // lsv_resultado
            // 
            this.lsv_resultado.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.lsv_resultado.Location = new System.Drawing.Point(578, 272);
            this.lsv_resultado.Name = "lsv_resultado";
            this.lsv_resultado.Size = new System.Drawing.Size(251, 191);
            this.lsv_resultado.TabIndex = 30;
            // 
            // btn_lerArquivo1
            // 
            this.btn_lerArquivo1.Location = new System.Drawing.Point(95, 481);
            this.btn_lerArquivo1.Name = "btn_lerArquivo1";
            this.btn_lerArquivo1.Size = new System.Drawing.Size(75, 23);
            this.btn_lerArquivo1.TabIndex = 31;
            this.btn_lerArquivo1.Text = "Ler Arquivo";
            this.btn_lerArquivo1.UseVisualStyleBackColor = true;
            this.btn_lerArquivo1.Click += new System.EventHandler(this.btn_lerArquivo1_Click);
            // 
            // btn_lerArquivo2
            // 
            this.btn_lerArquivo2.Location = new System.Drawing.Point(388, 481);
            this.btn_lerArquivo2.Name = "btn_lerArquivo2";
            this.btn_lerArquivo2.Size = new System.Drawing.Size(75, 23);
            this.btn_lerArquivo2.TabIndex = 32;
            this.btn_lerArquivo2.Text = "Ler Arquivo";
            this.btn_lerArquivo2.UseVisualStyleBackColor = true;
            this.btn_lerArquivo2.Click += new System.EventHandler(this.btn_lerArquivo2_Click);
            // 
            // btn_mostrar
            // 
            this.btn_mostrar.Location = new System.Drawing.Point(541, 151);
            this.btn_mostrar.Name = "btn_mostrar";
            this.btn_mostrar.Size = new System.Drawing.Size(75, 23);
            this.btn_mostrar.TabIndex = 33;
            this.btn_mostrar.Text = "Mostrar";
            this.btn_mostrar.UseVisualStyleBackColor = true;
            this.btn_mostrar.Click += new System.EventHandler(this.btn_mostrar_Click);
            // 
            // frm_matrizEsparsa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1102, 564);
            this.Controls.Add(this.btn_mostrar);
            this.Controls.Add(this.btn_lerArquivo2);
            this.Controls.Add(this.btn_lerArquivo1);
            this.Controls.Add(this.lsv_resultado);
            this.Controls.Add(this.lsv_2);
            this.Controls.Add(this.lsv_1);
            this.Controls.Add(this.lsv_matriz);
            this.Controls.Add(this.tbx_valor2);
            this.Controls.Add(this.lb_sinalResultado);
            this.Controls.Add(this.lb_sinalMat);
            this.Controls.Add(this.btn_multiplicarMatrizes);
            this.Controls.Add(this.btn_somarMatrizes);
            this.Controls.Add(this.btn_addValor);
            this.Controls.Add(this.lb_coluna);
            this.Controls.Add(this.lb_valor);
            this.Controls.Add(this.nmr_coluna);
            this.Controls.Add(this.lb_M);
            this.Controls.Add(this.lb_N);
            this.Controls.Add(this.btn_excluirElemento);
            this.Controls.Add(this.btn_excluirMatriz);
            this.Controls.Add(this.btn_Exibir);
            this.Controls.Add(this.btn_lerElemento);
            this.Controls.Add(this.btn_addElemento);
            this.Controls.Add(this.nmr_N);
            this.Controls.Add(this.nmr_M);
            this.Controls.Add(this.lb_valor2);
            this.Controls.Add(this.btn_criarMatriz);
            this.Controls.Add(this.tbx_valor);
            this.Controls.Add(this.btn_lerarq);
            this.Name = "frm_matrizEsparsa";
            this.Text = "MatrizEsparsa";
            this.Load += new System.EventHandler(this.btn_criarMatriz_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nmr_M)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmr_N)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmr_coluna)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lsv_matriz)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lsv_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lsv_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lsv_resultado)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_lerarq;
        private System.Windows.Forms.OpenFileDialog dlg_abrir;
        private System.Windows.Forms.TextBox tbx_valor;
        private System.Windows.Forms.Button btn_criarMatriz;
        private System.Windows.Forms.Label lb_valor2;
        private System.Windows.Forms.NumericUpDown nmr_M;
        private System.Windows.Forms.NumericUpDown nmr_N;
        private System.Windows.Forms.Button btn_addElemento;
        private System.Windows.Forms.Button btn_lerElemento;
        private System.Windows.Forms.Button btn_Exibir;
        private System.Windows.Forms.Button btn_excluirMatriz;
        private System.Windows.Forms.Button btn_excluirElemento;
        private System.Windows.Forms.Label lb_N;
        private System.Windows.Forms.Label lb_M;
        private System.Windows.Forms.Label lb_coluna;
        private System.Windows.Forms.Label lb_valor;
        private System.Windows.Forms.NumericUpDown nmr_coluna;
        private System.Windows.Forms.Button btn_addValor;
        private System.Windows.Forms.Button btn_somarMatrizes;
        private System.Windows.Forms.Button btn_multiplicarMatrizes;
        private System.Windows.Forms.Label lb_sinalMat;
        private System.Windows.Forms.Label lb_sinalResultado;
        private System.Windows.Forms.TextBox tbx_valor2;
        private System.Windows.Forms.DataGridView lsv_matriz;
        private System.Windows.Forms.DataGridView lsv_1;
        private System.Windows.Forms.DataGridView lsv_2;
        private System.Windows.Forms.DataGridView lsv_resultado;
        private System.Windows.Forms.Button btn_lerArquivo1;
        private System.Windows.Forms.Button btn_lerArquivo2;
        private System.Windows.Forms.Button btn_mostrar;
    }
}

