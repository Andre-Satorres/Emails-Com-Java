﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MatrizEsparsaED
{
    class Celula
    {
        private Celula direita; // ponteiro para a o próximo elemento não nulo na mesma linha
        private Celula abaixo;  // ponteiro para a o próximo elemento não nulo na mesma coluna
        private int linha, coluna;
        private double? valor;


        public Celula(Celula direita, Celula abaixo, double? valor, int linha, int coluna)
        {
            this.direita = direita;
            this.abaixo = abaixo;
            this.valor = valor;
            this.linha = linha;
            this.coluna = coluna;

        }

        public Celula(Celula direita, Celula abaixo, int linha, int coluna)
        {
            this.direita = direita;
            this.abaixo = abaixo;
            this.valor = null;
            this.linha = linha;
            this.coluna = coluna;

        }
        public Celula(Celula direita, Celula abaixo)
        {
            this.direita = direita;
            this.abaixo = abaixo;
            this.valor = null;
            this.linha = 0;
            this.coluna = 0;

        }

        public Celula(double? valor,int x,int y)
        {
            this.linha = y;
            this.coluna = x;
            this.valor = valor;
        }

        public double? getValor()
        {
            return this.valor;
        }

        public void setValor(double? valor)
        {
            this.valor = valor;
        }

        public Celula getDireita()
        {
            return this.direita;
        }

        public Celula getAbaixo()
        {
            return this.abaixo;
        }
        public void setDireita(Celula direita)
        {
            this.direita = direita;
        }

        public void setAbaixo(Celula abaixo)
        {
            this.abaixo = abaixo;
        }

        public int getLinha() {
            return this.linha;
        }
        public int getColuna()
        {
            return this.coluna;
        }
        public void setLinha(int linha)
        {
            this.linha = linha;
        }
        public void setColuna(int coluna)
        {
            this.coluna = coluna;
        }

    }
}
