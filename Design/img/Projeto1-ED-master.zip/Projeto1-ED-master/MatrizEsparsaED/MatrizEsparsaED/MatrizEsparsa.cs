﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MatrizEsparsaED
{
    class MatrizEsparsa
    {
        public static int valorCelulaNull = 0;
        Celula atual,primeiro;
        private int linha, coluna;

        public MatrizEsparsa(int x, int y)   //Usamos *Y* para representar colunas e *X* para representar linhas
        {
            primeiro = new Celula(primeiro,primeiro,null,0,0);

            this.coluna = y;
            this.linha = x;

            //criar a linha do X que seria (0,y)
            atual = primeiro;
            for (int i = 1; i <= y; i++)
            {
                Celula linhaY = new Celula(null, 0, i);
                atual.setAbaixo(linhaY);
                atual.setDireita(atual);
                atual = atual.getAbaixo();
            }
            atual.setAbaixo(primeiro);
            atual.setDireita(atual);
            //criar a linha do X que seria (x,0)
            atual = primeiro;
            for (int i = 1; i <= x; i++)
            {
                Celula linhaX = new Celula(null, i, 0);
                // verifica se e a primeiro para nao perder a lista das linhasY
                if (atual != primeiro)
                    atual.setAbaixo(atual);
                atual.setDireita(linhaX);
                atual = atual.getDireita();
            }
            atual.setAbaixo(atual);
            atual.setDireita(primeiro);
        }

        public void alterarCelula(double? valor, int x, int y)
        {
            atual = primeiro;//procura a celula
            for (int i = 0; i < x; i++)
            {
                atual = atual.getDireita();
            }
           
            for (int i = 0; i < y; i++)
            {
                atual = atual.getAbaixo();
            }

            atual.setValor(valor);//muda o valor da mesma
        }

        public void criarCelula(int x, int y, double? valor)
        {

            if (existeCelula(x, y) != true)
            {
                Celula adicionado = new Celula(valor, x, y);//cria a nova celula sem apontar para nada e nem ser apontado
                Celula linhaX = primeiro;
                Celula linhaY = primeiro;
                atual = primeiro;
                //apontar e ser apontado no eixo Y

                for (int i = 0; i < x; i++)
                {
                    linhaX = linhaX.getDireita();
                }

                for (int i = 0; i < y; i++)
                {
                    linhaY = linhaY.getAbaixo();
                }

                atual = linhaX;

                while ((atual.getAbaixo().getLinha() != 0) && (atual.getAbaixo().getLinha() != y))
                {
                    atual = atual.getAbaixo();  //Percorre a coluna até encontrar a posição.
                }
                adicionado.setAbaixo(atual.getAbaixo());
                atual.setAbaixo(adicionado);

                atual = linhaY;

                while ((atual.getDireita().getColuna() != 0) && (atual.getDireita().getColuna() != x))
                {
                    atual = atual.getDireita();     //Percorre a linha até encontrar a posição.
                }
                adicionado.setDireita(atual.getDireita());
                atual.setDireita(adicionado);

            }
            else
                alterarCelula(valor,x,y);

        }

        public void excluirCelula(int x , int y)
        {
            if (existeCelula(x, y) == true)//verifica se a celula em questao existe
            {

                //retira um dos ponteiros
                atual = primeiro;
                for (int i = 0; i < x; i++)
                {

                    atual = atual.getDireita();
                }

                while (atual.getAbaixo().getLinha() != y)
                {
                    atual = atual.getAbaixo();
                }

                atual.setAbaixo(atual.getAbaixo().getAbaixo());

                //retira um dos ponteiros

                atual = primeiro;

                for (int i = 0; i < y; i++)
                {
                    atual = atual.getAbaixo();
                }

                while (atual.getDireita().getColuna() != x)
                {
                    atual = atual.getDireita();
                }

                atual.setDireita(atual.getDireita().getDireita());
            }else
                throw new ArgumentException("Célula Inexistente");

        }

        public double? consultarCelula(int x , int y)
        {
            if (existeCelula(x, y) == true)//verifica se a celula existe se não existir retorna 0 que seria o valor padrão
            {
                //procura a celula e retorna o seu valor
                atual = primeiro;
                while (atual.getDireita().getColuna() < x)
                {
                    atual = atual.getDireita();
                }
                atual = atual.getDireita();

                while (atual.getAbaixo().getLinha() < y)
                {
                    atual = atual.getAbaixo();
                }
                atual = atual.getAbaixo();
                return atual.getValor();
            }
            else
                return valorCelulaNull;

        }

        public MatrizEsparsa somarMatrizes(MatrizEsparsa matriz2)
        {
            MatrizEsparsa matrizResultado = new MatrizEsparsa(coluna, linha); //cria a matriz resultado
        if ((this.linha == matriz2.linha) && (this.coluna == matriz2.coluna))//verifica se e possivel somar as duas matrizes
            {
                for(int i = 1; i <= coluna; i++)
                {
                    for (int j = 1; j <= linha; j++)
                    {
                        matrizResultado.criarCelula(i,j,(this.consultarCelula(i,j) + matriz2.consultarCelula(i,j)));//soma as celulas das matrizes
                    }
                }


                return matrizResultado;
            } else
                throw new ArgumentException("Tamanhos Errados");
        }
        
        public bool existeCelula(int x, int y)
        {
            atual = primeiro;
            bool verificador = true;
            //procura se existe uma celula nao vazia na matriz e retorna true ou false
            while ((atual.getDireita().getColuna() <= x) &&(verificador==true))
            {
                atual = atual.getDireita();
                if (atual.getDireita().getColuna() == 0)
                {
                    verificador = false;    //Se não existem colunas existeCelula() retorna falso.
                }
                
            }
            verificador = true;
            while ((atual.getAbaixo().getLinha() <= y)&& (verificador == true))
            {
                atual = atual.getAbaixo();
                if (atual.getAbaixo().getLinha() == 0)
                {
                    verificador = false;    //Se não existem linhas existeCelula() retorna falso.
                }
            }

            if ((atual.getColuna() == x)&&(atual.getLinha() == y))
            {
                return true;    //Caso existam linha e coluna, existeCelula() retorna verdadeiro.
            }
            else
                return false;

        }

        public void excluirMatrizEsparsa()
        {
            this.linha = 0;
            this.coluna = 0;
            this.primeiro = null;   //O nó cabeça recebe valor nulo para que não seja possível existir matriz.
            this.atual = null;
        }

        public void exibirDataGridView(DataGridView gridView)
        {
            gridView.Columns.Clear();
            gridView.Rows.Clear();
            // cria o cabeçalho das colunas
            for (int i = 1; i <= this.coluna; i++)
            {
                gridView.Columns.Add(i.ToString(), i.ToString());
            }

            string[] linhaMatriz = new string[this.coluna];

            // percorre as linhas da matriz e insere no gridView
            for (int j = 1; j <= this.linha; j++)
           {
                for (int k = 1; k <= this.coluna; k++)
                {
                    linhaMatriz[k - 1] = consultarCelula(j,k).ToString();
                }
                gridView.Rows.Add(linhaMatriz);
                gridView.Rows[j - 1].HeaderCell.Value = (j).ToString(); // adiciona cabeçalho da linha
            }
            gridView.AutoResizeColumns();
        }


        public override string ToString()
        {
            Celula linha = primeiro.getAbaixo();
            String resultado = "{ ";
            while (linha != primeiro)
            {
                Celula atualLinha = primeiro.getDireita();
                while (atualLinha != linha)
                {
                    resultado += atualLinha.ToString() + (atualLinha.getDireita() != linha ? ", " : " ");
                    atualLinha = atualLinha.getDireita();
                }
               linha = linha.getAbaixo();
            }
            return resultado + "}";
        }

        public MatrizEsparsa multiplicarMatrizes(MatrizEsparsa matriz2)
        {
            if (this.coluna == matriz2.linha)//verifica o tamanho
            {
                MatrizEsparsa matrizResultado = new MatrizEsparsa(matriz2.coluna,this.linha);
                double? total;
                for (int i = 0; i < this.linha; i++)
                {
                    for (int j = 0; j < matriz2.coluna; j++)
                    {
                        total = 0;
                        for (int k = 0; k < this.coluna; k++)
                        {
                            total = this.consultarCelula(k, i) * matriz2.consultarCelula(j, k); 
                        }
                        if (total != 0)
                        {
                            matrizResultado.criarCelula(j,i,total);
                        }
                        //Consulta o conteúdo das duas células de posições correspondentes e multiplica-os para formar o resultado final.
                    }
                }

                return matrizResultado;
            }
            else
                throw new ArgumentException("Tamanhos Errados");
        }

        public void somarColuna(double? valorSomaConstante, int x)
        {
            atual = primeiro;//procura a coluna e soma os valores a todos as celulas dessa coluna
            while (atual.getColuna() < x)
            {
                atual = atual.getDireita();
            }
            atual = atual.getAbaixo();
            for (int i = 1; i <= linha; i++)
            {
                if (atual.getLinha() != i)
                {
                    criarCelula(x, i, 0);
                    atual = atual.getAbaixo();
                }
                else
                atual = atual.getAbaixo();

            }

            atual = primeiro;//procura a coluna e soma os valores a todos as celulas dessa coluna
            while (atual.getColuna() < x)
            {
                atual = atual.getDireita();
            }
            while (atual.getLinha() < linha)
            {
                atual = atual.getAbaixo();
                atual.setValor(atual.getValor() + valorSomaConstante);
                
            }
            
            
        }

    }
}
