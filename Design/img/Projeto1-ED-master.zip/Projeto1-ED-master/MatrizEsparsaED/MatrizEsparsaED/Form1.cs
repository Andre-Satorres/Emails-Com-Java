﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MatrizEsparsaED
{
    public partial class frm_matrizEsparsa : Form
    {
        MatrizEsparsa matriz,matriz2,matriz3,matrizResultado;
        int coluna, linha;
        double valor;

        public frm_matrizEsparsa()
        {
            InitializeComponent();
        }

        private void btn_criarMatriz_Load(object sender, EventArgs e)
        {
            btn_Exibir.Enabled = false;
            btn_excluirElemento.Enabled = false;
            btn_addElemento.Enabled = false;
            btn_lerElemento.Enabled = false;
        }

        private void btn_somarMatrizes_Click(object sender, EventArgs e)
        {
            lb_sinalMat.Text = "+";
           matrizResultado= matriz2.somarMatrizes(matriz3);
            matrizResultado.exibirDataGridView(lsv_resultado);
        }

        private void btn_multiplicarMatrizes_Click(object sender, EventArgs e)
        {
            lb_sinalMat.Text = "x";
            matrizResultado = matriz2.multiplicarMatrizes(matriz3);
            matrizResultado.exibirDataGridView(lsv_resultado);
        }

        private void btn_criarMatriz_Click(object sender, EventArgs e)
        {
            converterInteiro();
            matriz = new MatrizEsparsa(coluna, linha);
            btn_criarMatriz.Enabled = false;
            btn_Exibir.Enabled = true;
            btn_excluirElemento.Enabled = true;
            btn_addElemento.Enabled = true;
            btn_lerElemento.Enabled = true;
        }

        private void converterInteiro()  //Este processo foi criado com a finalidade de converter os valores para o tipo "double".
        {
            coluna = Convert.ToInt32(Math.Round(nmr_M.Value, 0));
            linha = Convert.ToInt32(Math.Round(nmr_N.Value, 0));
        }

        private void btn_lerarq_Click(object sender, EventArgs e)
        {
            if (dlg_abrir.ShowDialog() == DialogResult.OK)
            {
                StreamReader sr = new StreamReader(dlg_abrir.FileName);

                string linhaArquivo = sr.ReadLine();


                string[] coordenadas = linhaArquivo.Split(' ');

                int linhas = Convert.ToInt32(coordenadas[0]);
                int colunas = Convert.ToInt32(coordenadas[1]);

                            matriz = new MatrizEsparsa(linhas, colunas);
                

                while ((linhaArquivo = sr.ReadLine()) != null)
                {

                    string[] celula = linhaArquivo.Split(' ');

                    double elemento = Convert.ToDouble(celula[0]);
                    int linha = Convert.ToInt32(celula[1]);
                    int coluna = Convert.ToInt32(celula[2]);


                                matriz.criarCelula( linha, coluna, elemento);

                                matriz.exibirDataGridView(lsv_matriz);

                    btn_criarMatriz.Enabled = false;
                    btn_Exibir.Enabled = true;
                    btn_excluirElemento.Enabled = true;
                    btn_addElemento.Enabled = true;
                    btn_lerElemento.Enabled = true;


                }
                sr.Close();
            }


        }

        private void btn_addValor_Click(object sender, EventArgs e)
        {
            valor = Convert.ToDouble(tbx_valor2.Text); 
            converterInteiro();
            matriz.somarColuna(valor, coluna);
        }

        private void btn_lerElemento_Click(object sender, EventArgs e)
        {
            converterInteiro();
            MessageBox.Show(matriz.consultarCelula(coluna, linha).ToString());

        }

        private void btn_Exibir_Click(object sender, EventArgs e)
        {
            matriz.exibirDataGridView(lsv_matriz);
        }

        private void lsv_Elemento2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_lerArquivo2_Click(object sender, EventArgs e)
        {
            if (dlg_abrir.ShowDialog() == DialogResult.OK)
            {
                StreamReader sr = new StreamReader(dlg_abrir.FileName);
                string linhaArquivo = sr.ReadLine();
                string[] coordenadas = linhaArquivo.Split(' ');
                int linhas = Convert.ToInt32(coordenadas[0]);
                int colunas = Convert.ToInt32(coordenadas[1]);
                matriz3 = new MatrizEsparsa(linhas, colunas);
                while ((linhaArquivo = sr.ReadLine()) != null)
                {
                    string[] celula = linhaArquivo.Split(' ');
                    double elemento = Convert.ToDouble(celula[0]);
                    int linha = Convert.ToInt32(celula[1]);
                    int coluna = Convert.ToInt32(celula[2]);
                    matriz3.criarCelula(linha, coluna, elemento);
                    matriz3.exibirDataGridView(lsv_2);
                }
                sr.Close();
            }
        }

        private void btn_mostrar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(matriz.ToString());
        }

        private void btn_excluirMatriz_Click(object sender, EventArgs e)
        {
            matriz.excluirMatrizEsparsa();
            btn_Exibir.Enabled = false;
            btn_excluirElemento.Enabled = false;
            btn_addElemento.Enabled = false;
            btn_lerElemento.Enabled = false;
            btn_criarMatriz.Enabled = true;
            lsv_matriz.Rows.Clear();
            lsv_matriz.Columns.Clear();

        }

        private void btn_excluirElemento_Click(object sender, EventArgs e)
        {
            converterInteiro();
            matriz.excluirCelula(coluna,linha);

        }


        private void btn_addElemento_Click(object sender, EventArgs e)
        {
            converterInteiro();
            valor = Convert.ToDouble(tbx_valor.Text);
            matriz.criarCelula(coluna, linha, valor);
        }

        private void btn_lerArquivo1_Click(object sender, EventArgs e)
        {
            if (dlg_abrir.ShowDialog() == DialogResult.OK)
            {
                StreamReader sr = new StreamReader(dlg_abrir.FileName);
                string linhaArquivo = sr.ReadLine();
                string[] coordenadas = linhaArquivo.Split(' ');
                int linhas = Convert.ToInt32(coordenadas[0]);
                int colunas = Convert.ToInt32(coordenadas[1]);    
                matriz2 = new MatrizEsparsa(linhas, colunas);
                while ((linhaArquivo = sr.ReadLine()) != null)
                {
                    string[] celula = linhaArquivo.Split(' ');
                    double elemento = Convert.ToDouble(celula[0]);
                    int linha = Convert.ToInt32(celula[1]);
                    int coluna = Convert.ToInt32(celula[2]);
                    matriz2.criarCelula(linha, coluna, elemento);
                    matriz2.exibirDataGridView(lsv_1);
                }
                sr.Close();
            }
        }

    }
}
